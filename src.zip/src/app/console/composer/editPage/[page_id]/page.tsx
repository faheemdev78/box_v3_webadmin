'use client'

import React, { useState, useEffect, useRef, ReactNode } from 'react'
import { Button, DeleteButton, DevBlock, Icon, IconButton, Loader } from '@/components';
import { Form as FinalForm, Field as FinalField, useForm } from 'react-final-form';
import { FieldArray } from 'react-final-form-arrays'
import arrayMutators from 'final-form-arrays'
import { submitHandler, ExternalSubmitButton } from '@/components/form';
import { useMutation, useLazyQuery } from '@apollo/client/react';
import _ from 'lodash'
import { __error, __yellow } from '@/lib/consoleHelper';
import { DndContext, closestCenter, useSensor, useSensors, PointerSensor, DragOverlay } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { restrictToVerticalAxis, restrictToWindowEdges } from '@dnd-kit/modifiers';
import { Alert, Row, Col, Space, Card, message, Dropdown, Modal } from 'antd';
import { CSS } from '@dnd-kit/utilities';
import { useDrop, useDrag } from 'ahooks';
import { catchApolloError, checkApolloRequestErrors, dateToUtc, parseJson, sleep, timestamp, uploadFile, utcToDate, utcToDateField } from "@/lib/utill";
import { PageTypeSelection, PageSettings, SideMenu, PropsWindow } from '@/modules/composer';
import { components } from '@/modules/composer/components';
import { useRouter, useParams } from 'next/navigation';
import { adminRoot, defaultPageSize, defaultTZ } from '@/configs';
import styles from '@/modules/composer/Composer.module.scss';
import { parseStylesInput } from '@/modules/composer/lib';
import AppPageEditForm from '@/modules/composer/appPageEditForm';

import AppScheduleEditForm from '../../components/appScheduleEditForm';

import FETCH_MODULES from '@/graphql/app_pages_modules/appPagesModulesQuery.graphql'
import FETCH_DATA from '@/graphql/app_pages/appPage.graphql'
import SAVE_ROWS from '@/graphql/app_pages_modules/saveAppPagesModules.graphql'
import DELETE_ROW from '@/graphql/app_pages_modules/deleteAppPagesModules.graphql'
import PUBLISH_PAGE from '@/graphql/app_pages/publishAppPage.graphql'


function ItemRender({ item, item: { data, value, name } }: { item: any }) {
    let found = components.find(o => o.type == data?.type)
    if (!found) return <Alert type="error" title="Error!" description={`Invalid field (${data?.type})`} />

    return found.renderer ? found.renderer({ item }) : <p>NO renderor</p>
}

const RowRender = ({ item }: { item: any }) => {
    if (!item.data) return <div style={{ border: "1px dashed blue", padding: "10px", margin: "10px" }}>Empty</div>;
    return (<div className={styles.data_item}>
        <ItemRender item={item} />
    </div>)
}

const DataRow = ({ thisNode, row_id, onItemDrop, field_name }: {
    thisNode: any,
    row_id: string | number,
    onItemDrop: Function,
    field_name: string
}) => {
    const [isHovering, setIsHovering] = useState(false);
    const dropRef = useRef(null);

    useDrop(dropRef, {
        onDom: (dropItem, e) => {
            // alert(`custom: ${dropItem.label} dropped into zone ${row_id}`);
            onItemDrop({ item: dropItem, zone: row_id, id: thisNode.id })
        },
        onDragOver: () => setIsHovering(true),
        // onDragEnter: () => setIsHovering(true),
        onDragLeave: () => setIsHovering(false),
        onDrop: () => setIsHovering(false),
    });

    // if (thisNode.styles) console.log("thisNode: ", thisNode)

    return (<div ref={dropRef}>
        <div style={{ backgroundColor: `${isHovering ? 'rgba(0, 0, 255, 0.1)' : 'transparent'}` }}>
            <RowRender item={thisNode} />
            {/* {children} */}
        </div>
    </div>)
}

const AddRowButton = ({ fields }: { fields: any }) => {
    return (<div style={{ padding: "20px", textAlign: "center" }}>
        <IconButton size="large" color="blue" shape="circle" onClick={() => fields.push({ id: timestamp(), val: fields.length })} icon="plus" />
        {/* <Button onClick={() => fields.push({ id: timestamp(), val: fields.length })}>Add Row</Button> */}
    </div>)
}

// Sortable Field Component
const SortableField = ({ id, name, remove, index, children, onClick, onEdit, onRemove, selected }: {
    id: string, name: string, remove: any, index: string | number, children: ReactNode,
    onClick: React.MouseEventHandler<HTMLDivElement>,
    onEdit?: (() => Promise<any>) | undefined,
    onRemove?: (() => Promise<boolean>) | undefined,
    selected: boolean
}) => {
    const [busy, setBusy] = useState(false)
    // const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: id });
    const args = useSortable({ id: id });
    const { active, attributes, listeners, setNodeRef, transform, transition } = args;

    const onRemoveClick = async () => {
        setBusy(true)
        if (onRemove) await onRemove()
        setBusy(false)
    }

    const style = {
        // display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        transform: CSS.Transform.toString(transform), //transition,
        // border: "5px solid red",
    };
    // if (active && active.id == id) Object.assign(style, { height:"50px !important", overflow:"hidden", display:"block" })
    // if (active) console.log("active: ", active)

    let className = `${styles.data_row}`
    if (selected) className += ` ${styles.selected}`

    return (<Loader loading={busy}>
        <div className={className} ref={setNodeRef} style={style}>
            <div onClick={onClick}>{children}</div>

            <div className={styles.data_row_menu}>
                <Space>
                    {/* <IconButton onClick={onEdit} size="small" icon="pen" shape="circle" /> */}
                    <DeleteButton onClick={onRemoveClick} loading={busy} disabled={!onRemove} size="small" />
                    <span />
                </Space>
                {/* <Row gutter={[10, 10]} className='nowrap'>
                    <Col><Button size="small" onClick={onEdit}>Edit</Button></Col>
                    <Col><Button disabled={!onRemove} size="small" onClick={onRemove}>Delete</Button></Col>
                </Row> */}
            </div>
            <div {...attributes} {...listeners} className={styles.data_row_dragger}><div className={styles.bg} /></div>

            {(selected) && <div className={styles.selected} />}
        </div>
    </Loader>)
};

function PublishButton({ published, disabled, setError, onUpdate }: {
    published: boolean, disabled: boolean, setError: (val: string | null) => void, onUpdate?: (val: any) => void
}) {
    const form = useForm()

    const [publishAppPage, publishAppPage_details] = useMutation<any>(PUBLISH_PAGE); // { data, loading, error }

    const updatePublish = async () => {
        setError(null);
        const { rows, _id } = form.getState().values || {};

        if (!rows?.length || !rows[0]?._id) {
            setError("Oops! Seems like you haven't added anything into the page yet!");
            return;
        }

        // Get the latest value from state (safe inside event handler)
        const newPublished = !published;
        const input = { _id, published: newPublished };

        const result = await publishAppPage({ variables: { input } })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: false, parseReturn: (rr: any) => rr?.data?.publishAppPage }))
            .catch(catchApolloError);

        if (result.error) {
            setError(result?.error?.message || "Invalid response");
            return;
        }

        message.success(newPublished ? "Published" : "Unpublished");
        onUpdate?.(result);
    }

    return (<Button
        onClick={updatePublish}
        color={published ? "green" : 'red'}
        loading={publishAppPage_details.loading}
        disabled={disabled}
    >{published ? 'Published' : 'Un-Published'}</Button>)
}


// export default function EditAppPage({ params }){
function EditAppPage() {
    const { page_id } = useParams<{ page_id: string }>()

    const [fatelError, set_fatelError] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [saving, setSaving] = useState(false);
    const [busy, setBusy] = useState(false);
    const [pageData, set_pageData] = useState<any>(null); // useState<{ rows: any, _id:string } | null>(null)
    const [showProps, set_showProps] = useState<any | boolean>(false)
    const [sortDragging, set_sortDragging] = useState(null);
    // const [publishing, set_publishing] = useState(false);
    const [loadingModules, set_loadingModules] = useState(false);
    const [modulesPageNum, set_modulesPageNum] = useState(1);
    const [showPageEdit, set_showPageEdit] = useState(false);
    const [showScheduleEdit, set_showScheduleEdit] = useState(false);

    const [deleteAppPagesModules, delRow_details] = useMutation<any>(DELETE_ROW); // { data, loading, error }
    const [saveAppPagesModules, saveRows_details] = useMutation<any>(SAVE_ROWS); // { data, loading, error }
    // const [publishAppPage, publishAppPage_details] = useMutation(PUBLISH_PAGE); // { data, loading, error }

    const [appPage, { called, loading }] = useLazyQuery<any>(FETCH_DATA, { fetchPolicy: 'network-only' });
    const [appPagesModulesQuery, modules_load] = useLazyQuery<any>(FETCH_MODULES, { fetchPolicy: 'network-only' });


    useEffect(() => {
        if (called) return;
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page_id, called])

    const fetchData = async () => {
        console.log(__yellow("fetchData()"));

        let results = await appPage({
            variables: {
                filter: JSON.stringify({ _id: page_id }),
            }
        })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.appPage }))
            .catch(catchApolloError)

        if (!results || results.error) {
            set_fatelError((results && results.error.message) || "No page data found!")
            return false;
        }

        let modules = await fetchModules(1);
        if (modules === false) console.log("modules: ", modules)
        if (modules === false) return false;

        parseData({ ...results, rows: (modules && modules.edges) || [] })
        return false;
    }

    const fetchModules = async (_modulesPageNum: number) => {
        set_loadingModules(true);
        set_modulesPageNum(_modulesPageNum)

        let results = await appPagesModulesQuery({
            variables: {
                limit: defaultPageSize,
                page: _modulesPageNum, //_pagination.pageSize * (_pagination.current - 1),
                filter: JSON.stringify({ _id_parent: page_id }),
                others: JSON.stringify({ sort: { sort_order: 1 } })
            },
        })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.appPagesModulesQuery }))
            .catch(catchApolloError)
        set_loadingModules(false);

        if (!results || results.error) {
            set_fatelError((results && results?.error?.message) || 'No Modules found!');
            return false;
        }
        return results;
    }

    const parseData = (_data: any) => {
        let results = { ..._data };

        if (results.rows) {
            Object.assign(results,
                {
                    rows: results.rows.map((o: any) => {
                        let values = parseJson(o.values);
                        return {
                            ...o,
                            id: o._id,
                            schedule_start: o.schedule_start && utcToDateField(o.schedule_start),
                            schedule_end: o.schedule_end && utcToDateField(o.schedule_end),
                            values: (!values || values == "null" || values == "undefined") ? undefined : values
                        }
                    })
                }
            )
        }

        if (results.error) setError(results.error.message)
        else set_pageData(results);
        return results;
    }

    const onDeleteRow = async (row: any, callback: Function) => {
        if (row._id) {
            let resutls = await deleteAppPagesModules({ variables: { _id: row._id } })
                .then(r => checkApolloRequestErrors({ results: r, allowEmpty: false, parseReturn: (rr: any) => rr?.data?.deleteAppPagesModules }))
                .catch(catchApolloError)

            if (!resutls || resutls.error) {
                message.error((resutls && resutls.error.message) || "Invalid Response!")
                return false;
            }

            let rows = pageData && pageData.rows.filter((o: any) => (o._id !== row._id))
            set_pageData((prev: any) => ({ ...prev, rows }))
            message.success("Modules removed!")
        }
        else {
            message.success("Removing local module")
        }

        callback()
        return false;
    }

    const onSubmit = async ({ rows }: { rows: any }) => {
        console.log(__yellow("onSubmit()"), rows)
        setError(null)

        if (!rows || rows.length < 1 || !rows[0]?.id) {
            setError("Oops! Seems like your havent added anything into the page yet!")
            return false;
        }

        let uploadArray = [];

        let input = {
            _id: pageData && pageData._id,
            rows: rows.map((row: any, row_index: number) => {
                if (!row?.data?.type) return false;

                let _values;// = { ...row.values }
                if (_.isString(row.values)) _values = row.values

                else if (row.data.type == 'prod_list_3_2') {
                    _values = JSON.stringify({
                        ...row.values,
                        products: row.values.products.map((prod: any) => ({ _id: prod._id }))
                    })
                }

                else {
                    _values = JSON.stringify(row.values)
                }

                if (row.styles?.background?.upload_image && row.styles.background.upload_image[0]) {
                    uploadArray.push({ file: row.styles.background.upload_image[0], row_index })
                }

                return ({
                    _id: row._id,
                    _id_parent: pageData && pageData._id,
                    schedule_start: row.schedule_start ? dateToUtc(row.schedule_start.startOf('day'), { tz: defaultTZ }) : undefined,
                    schedule_end: row.schedule_end ? dateToUtc(row.schedule_end.endOf('day'), { tz: defaultTZ }) : undefined,
                    linked_to: 'page',
                    status: row.status || 'online',
                    data: {
                        desc: row.data.desc,
                        label: row.data.label,
                        type: row.data.type,
                    },
                    values: _values, // _.isString(row.values) ? row.values : JSON.stringify(row.values),
                    styles: parseStylesInput(row.styles),
                    sort_order: row_index,
                })

            }),
        }

        // console.log("input: ", input)
        // return { error:{message:"testing"}}

        // verify that there is no empty ROW
        if (!input.rows || input.rows.length < 1 || input.rows.includes(false)) {
            setError("Loooks like you have one or more empty rows, please populate the row(s) or remove!")
            return false;
        }

        setSaving(true)
        let results = await saveAppPagesModules({ variables: { input: input.rows } }).then((r: any) => (r?.data?.saveAppPagesModules))
            .catch((err: Error) => {
                console.log(__error("Error: "), err)
                return { error: { message: "Unable to complete your request at the moment." } }
            })

        if (results.error) {
            setError(results.error.message);
            message.error(results.error.message)
        }
        else message.success("Saved")

        // await sleep(1500)
        // parseData({ ...pageData, rows: results, published: false })
        await fetchData();
        setSaving(false)
        return false;
    }

    // const uploadImage = async (file) => {
    //     let result = uploadFile({ file, data: { upload_type: "page_assets" } }).catch(err => {
    //         console.log(__error("Error: "), err)
    //         return { error: { message: "Unable to comeplte upload!" } }
    //     })

    //     if (!result || result.error) {
    //         setError((result && result.error.message) && "Invalid Upload response!")
    //         return false;
    //     }

    //     return result;
    // }

    // const updatePublish = async (values: any, published:boolean) => {
    //     console.log("updatePublish() ", values)

    //     // const form = useForm()
    //     // let _values = form.getState().values
    //     // console.log("_values: ", _values)

    //     // const { rows, published } = values;

    //     // if (!rows || rows.length < 1 || !rows[0]?._id) {
    //     //     setError("Oops! Seems like your havent added anything into the page yet!")
    //     //     return false;
    //     // }
    //     // setError(null);

    //     // return false;

    //     // set_publishing(true)
    //     // let result = await publishAppPage({ variables: { input: { _id: pageData._id, published } } })
    //     //     .then(r => checkApolloRequestErrors({ results: r, allowEmpty: false, parseReturn: (rr:any) => rr?.data?.publishAppPage }))
    //     //     .catch(catchApolloError)
    //     // set_publishing(false)

    //     // if (!result || result.error) {
    //     //     setError((result && result?.error?.message) || "Invalid response")
    //     //     return false;
    //     // }

    //     // message.success("Published")

    //     // set_pageData((prev:any) => ({ ...prev, published: published }))
    // }

    const toggleSettings = () => set_showPageEdit(!showPageEdit)
    const toggleSchedule = () => set_showScheduleEdit(!showScheduleEdit)

    const onSettingsUpdate = (values: any) => {
        set_pageData((prev: any) => ({ ...prev, ...values }))
        if (showPageEdit) toggleSettings()
        if (showScheduleEdit) toggleSchedule()
    }



    // Initialize sensors
    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 10, // Minimum movement in pixels to start dragging
            },
        })
    );
    const handleDragEnd = (fields: any) => (event: any) => {
        set_sortDragging(null);

        const { active, over } = event;

        if (active.id !== over.id) {
            // const oldIndex = fields.value.indexOf(active.id);
            // const newIndex = fields.value.indexOf(over.id);
            const oldIndex = fields.value.findIndex((o: any) => o.id == active.id)
            const newIndex = fields.value.findIndex((o: any) => o.id == over.id)
            // console.log(`Move ${oldIndex} to ${newIndex}`)

            fields.move(oldIndex, newIndex);
        }
    };

    const onItemClick = (vals: any) => set_showProps(vals)
    const handleDragStart = (event: any) => set_sortDragging(event.active.id);

    if (fatelError) return <Alert title="Error" description={fatelError} type='error' showIcon />
    if (loading && !pageData) return <Loader loading={true} />
    if (!pageData) return <Loader loading={true}>Parsing data...</Loader>


    return (<>
        <FinalForm onSubmit={onSubmit} initialValues={pageData}
            mutators={{ ...arrayMutators }}
            render={(formargs) => {
                const { handleSubmit, submitting, form, values, invalid, errors, submitFailed, dirty } = formargs;

                const onItemDrop = ({ item, zone, id }: any, { field, fields, index }: any) => {
                    // alert(`custom: ${item.label} dropped into zone ${zone}`);
                    // let data = field?.data?.slice() || [];
                    //     data.push(item)

                    // fields.update(index, { ...field, data: item })
                    fields.update(index, { id, zone, data: item })
                }

                const hasNoRows = values?.rows?.length < 1;
                const hasEmptyRows = values?.rows?.length > 0 && !values?.rows[0]?._id;
                const disablePublish = hasEmptyRows || dirty;
                const disableSave = !dirty;// || hasEmptyRows;

                return (<>
                    {error && <Alert title="Error" description={error} showIcon type='error' />}
                    <form id="page_composer_form" {...submitHandler(formargs)}>

                        <div style={{ borderBottom: "1px solid #D0DAE5", padding: "10px", backgroundColor: "#FFF" }}>
                            <Row gutter={[20, 20]}>
                                <Col span={8}><Space>
                                    <Button onClick={toggleSettings} tooltip={{ title: "Settings", placement: "bottom" }} icon={<Icon icon="cog" />} />
                                    <Button onClick={toggleSchedule} tooltip={{ title: "Schedule", placement: "bottom" }} icon={<Icon icon="clock" />} />
                                </Space></Col>
                                <Col span={8} style={{ textAlign: 'center' }}>
                                    {/* <Space separator="|"><div>Web</div><div>Mobile</div></Space> */}
                                    <h4>{pageData.title}</h4>
                                </Col>
                                <Col span={8} style={{ textAlign: 'right' }}><Space>
                                    {/* {dirty && <Alert type='warning' showIcon title="Error" description="Contents updated" />} */}
                                    <ExternalSubmitButton
                                        color="orange"
                                        disabled={disableSave}
                                        loading={saving}
                                        label="Save"
                                        form_id="page_composer_form"
                                    />
                                    <PublishButton
                                        published={pageData.published}
                                        disabled={!!disablePublish}
                                        setError={setError}
                                        onUpdate={(val) => {
                                            set_pageData((prev: any) => ({ ...prev, published: val.published }))
                                        }}
                                    />
                                </Space></Col>
                            </Row>
                        </div>


                        <Row gutter={[0, 0]}>
                            <Col><SideMenu /></Col>

                            <Col flex="auto" style={{ border: "0px solid black", textAlign: 'center' }}>

                                <div className={`${styles.mob_view_wrapper} ${styles.custom_scroller}`}>
                                    <div className={styles.mob_view} style={{ textAlign: 'left' }}>
                                        <FieldArray name="rows">
                                            {({ fields }) => {
                                                return (<>
                                                    <DndContext
                                                        sensors={sensors}
                                                        collisionDetection={closestCenter}
                                                        onDragStart={handleDragStart}
                                                        // onDragEnd={handleDragEnd}
                                                        onDragEnd={handleDragEnd(fields)}
                                                        modifiers={[restrictToVerticalAxis]}
                                                    >
                                                        <SortableContext items={fields?.value?.map(({ id }) => id)} strategy={verticalListSortingStrategy}>
                                                            {fields.map((name, index) => {
                                                                const thisNode = fields.value[index];

                                                                return (<div key={index}>
                                                                    <SortableField
                                                                        selected={showProps && (showProps.id == thisNode.id)}
                                                                        onClick={() => onItemClick({ ...thisNode, name })}
                                                                        // onRemove={fields.length < 2 ? undefined : () => fields.remove(index)}
                                                                        onRemove={(fields?.length ?? 0) < 2 ? undefined : async () => onDeleteRow(thisNode, () => fields.remove(index))}
                                                                        // onEdit={() => console.log("EDIT")}
                                                                        id={thisNode.id} name={name} index={index} remove={fields.remove}>
                                                                        <DataRow
                                                                            thisNode={thisNode}
                                                                            field_name={name}
                                                                            row_id={index}
                                                                            // onItemClick={onItemClick}
                                                                            onItemDrop={(args: any) => onItemDrop(args, { field: thisNode, fields, index })}
                                                                        />
                                                                    </SortableField>
                                                                </div>)

                                                            })}
                                                        </SortableContext>
                                                    </DndContext>

                                                    <AddRowButton fields={fields} />
                                                </>)
                                            }}
                                        </FieldArray>
                                    </div>
                                </div>

                                <DevBlock obj={values?.rows} title="values.rows" />

                            </Col>

                            {showProps && <Col><PropsWindow item={showProps} onClose={() => set_showProps(false)} /></Col>}
                        </Row>


                        <Modal
                            footer={false}
                            // closable={!busy} cancelButtonProps={{ disabled: busy }} confirmLoading={busy}
                            // onOk={() => savePageSettings(values)}
                            title="Page Settings"
                            width="1000px"
                            open={showPageEdit}
                            onCancel={() => set_showPageEdit(false)}
                        >
                            <AppPageEditForm onCancel={() => set_showPageEdit(false)} onUpdate={onSettingsUpdate} />
                        </Modal>

                        <Modal
                            footer={false}
                            closable={!busy}
                            cancelButtonProps={{ disabled: busy }}
                            // confirmLoading={busy}
                            // onOk={() => savePageSettings(values)}
                            title="Page Schedule"
                            width="500px"
                            open={showScheduleEdit}
                            onCancel={() => set_showScheduleEdit(false)}
                        >
                            <AppScheduleEditForm onCancel={() => set_showScheduleEdit(false)} onUpdate={onSettingsUpdate} />
                        </Modal>

                        {/* <DevBlock obj={{ ...values }} /> */}
                    </form>
                </>)

            }}
        />



        <DevBlock obj={pageData} />
    </>)
}

export default EditAppPage;
