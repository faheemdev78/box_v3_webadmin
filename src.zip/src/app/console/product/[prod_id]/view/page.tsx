'use client'

// import React, { useState, useEffect, useRef } from 'react'
import { __error, __yellow } from '@/lib/consoleHelper';
import { ProductView, ProductWrapper } from "@/modules/products";
import { Alert, Card } from 'antd';
// import { DevBlock } from '@/components';
// import { useAppSelector } from '@/rStore/hooks';

// interface ViewProductFormWrapper_Props {
//     product, 
//     session, 
//     refresh,
// }


function ViewProductFormWrapper({ product, session, refresh, store }: { product: any; session: any; refresh: any; store: any }) {
    if (!session || !session?.user?._id) return <Alert title="Error" description="Invalid user session" showIcon type='error' />

    return (<>
        <ProductView initialValues={product} session={session} store={store} refresh={refresh} />
    </>)
}

function Wrapper(props: any){
    // const store = useAppSelector(({ session }) => session.store);

    return (<ProductWrapper 
        {...props} 
        render={({ product, session, refresh, store }: { product: any; session: any; refresh: any; store: any }) => (<ViewProductFormWrapper 
            store={store}
            product={product} 
            session={session} 
            refresh={refresh} 
            {...props}
        />)}
    />)
}

export default Wrapper;
