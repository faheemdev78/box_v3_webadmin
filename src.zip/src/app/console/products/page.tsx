import React from 'react'

export default function ProductsDashboard() {
    return (<div>
        <h1>Products Dashboard</h1>
    </div>)
}
