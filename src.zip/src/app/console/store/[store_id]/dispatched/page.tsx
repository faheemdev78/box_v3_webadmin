'use client';

import { useEffect, useState } from "react";
import { useMutation, useLazyQuery } from '@apollo/client/react';
import { __error } from '@/lib/consoleHelper';
import { adminRoot, defaultPageSize, defaultPagination } from "@/configs";
import { Card, message, Row, Space, Tag, Typography } from "antd";
import { catchApolloError, checkApolloRequestErrors } from "@/lib/utill_apollo";
import { Button, DevBlock, OrderTable, usePageProps } from '@/components';
import { Page } from "@/template";
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';

import LIST_DATA from '@/graphql/order/getDispatchedQueue.graphql';

dayjs.extend(relativeTime);

const { Title, Text } = Typography;
const defaultFilter = {};


function DispatchedList(props:any) {
    const { store } = usePageProps() as unknown as { store: any }
  
    const [state, setState] = useState({
        pagination: defaultPagination,
        pageView: "list",
        dataSource: null,
        filter: { ...defaultFilter },
        others: {},
        _id_store: store._id,
    })

    const [getDispatchedQueue, { called, loading }] = useLazyQuery<any>(LIST_DATA, { fetchPolicy: 'network-only' });
  
    const fetchData = async ({ filter = {}, pagination = {} }: { 
        filter?: any, 
        pagination?: { pageSize?: number; current?: number }
    } = {}) => {
      const variables = {
          limit: pagination?.pageSize || state.pagination.pageSize,
          page: pagination?.current || state.pagination.current,
          filter: filter || state.filter || {},
          others: (state as any).others || {},
          _id_store: store._id,
      }

        const resutls = await getDispatchedQueue({ 
          variables: {
              ...variables,
              filter: JSON.stringify({ ...variables.filter, 'store._id': store._id }),
              others: JSON.stringify(variables.others || {})
          }
        })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr:any) => rr?.data?.getDispatchedQueue }))
          .catch(catchApolloError)

        if (resutls && resutls.error) {
            message.error(resutls.error.message);
            return;
        }

        setState({
            ...state,
            pagination: { 
                ...state.pagination,
                current: resutls.pagination.page,
                total: resutls.pagination.totalDocs,
                pageSize: resutls.pagination.limit,
            },
            filter: variables.filter,
            dataSource: resutls?.edges || [],
        })

    }

    useEffect(() => {
        if (called || loading) return
        fetchData({})
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [called, loading])
    

    return (<>
        <Page>
            <Card
                title={<Space>
                    <Title level={3} style={{ margin: 0 }}>Dispatched</Title>
                    {!loading && <Tag color="green">{state?.pagination?.total || 0} orders found</Tag>}
                </Space>}
                extra={<Button onClick={() => fetchData({})} loading={loading}>Refresh</Button>}
                styles={{ body: { padding: 0 } }}
            >
                <OrderTable
                    busy={false} 
                    columns={['serial', 'customer', 'picker', 'order', 'delivery_slot', 'status', 'createdAt', {
                        key: 'actions',
                        options: { reset: true, till_verification: false }
                    }]} 
                    dataSource={state.dataSource}
                    pagination={state.pagination}
                    scroll={{ x: 1200 }}
                />
            </Card>
        </Page>

    </>)
}

export default DispatchedList;
