'use client';

import { useEffect, useState } from "react";
import { useMutation, useLazyQuery } from '@apollo/client/react';
import { __error, __yellow } from '@/lib/consoleHelper';
import { ProductsList } from "@/modules/products";
import { adminRoot, defaultPageSize, defaultPagination } from "@/configs";
import { Alert, Card, message, Row } from "antd";
import { Loader, usePageProps } from "@/components";
import { checkApolloRequestErrors, catchApolloError } from "@/lib/utill_apollo";
import { useAppSelector } from "@/rStore/hooks";
import { getSession } from "@/rStore/slices/sessionSlice";

import LIST_DATA from '@/graphql/product/productsQuery.graphql'

const defaultFilter = {}; // { status: 'online' }



function StoreProductsHome(props:any) {
    // const session = useSelector((state) => state.session);
    const session = useAppSelector(getSession)
    const pageProps = (usePageProps() as any) || {};
    const store = pageProps?.store || {}

    const [state, setState] = useState({
        pagination: defaultPagination,
        pageView: "list",
        dataSource: null,
        filter: { ...defaultFilter },
        others: {},
    })
    const [busy, setBusy] = useState(false)
    const [error, setError] = useState(null)

    const [productsQuery, { called, loading }] = useLazyQuery<any>(LIST_DATA, { fetchPolicy: 'network-only' });

    useEffect(() => {
        if (called || loading) return
        fetchData({ filter: defaultFilter })
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [called, loading])

    
    const fetchData = async ({ filter, pagination = {} }: { filter?: any; pagination?: any } = {}) => {
        // console.log(__yellow("fetchData()"), { filter, pagination })
        
        const variables = {
            limit: pagination?.pageSize || state.pagination.pageSize,
            page: pagination?.current || state.pagination.current,
            filter: filter || state.filter || {},
            others: state.others || {},
        }

        setBusy(true)
        const resutls = await productsQuery({
            variables: {
                ...variables,
                filter: JSON.stringify(variables.filter || {}),
                others: JSON.stringify(variables.others || {}),
                _id_store: store._id
            }
        })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.productsQuery }))
            .catch(catchApolloError)

        setBusy(false)

        if (resutls && resutls.error) {
            message.error(resutls.error.message);
            setError(resutls.error.message)
            return;
        }

        setState((prev:any) => ({
            ...prev,
            pagination: {
                ...state.pagination,
                current: resutls.pagination.page,
                total: resutls.pagination.totalDocs,
                // resutls.pagination.totalPages,
                pageSize: resutls.pagination.limit,
            },
            filter: variables.filter,
            dataSource: resutls?.edges?.map((o: any) => {
                return {
                    ...o,
                    children: o.variations, //o?.variations?.length > 0 && o.variations,
                    variations: undefined
                }
            }),
        }))

    }

    if (!session) return <Loader loading={true}>Fetching session...</Loader>

    // let columns = ['title', 'barcode', 'variations_count', 'store_price', 'store_qty', 'store_reserved_qty', 'store_status'];
    let columns = ['title', 'categories', 'variations_count', 'barcode', 'status', 'store']
    // if (!session?.store_id) columns = undefined; // ['title', 'barcode', 'variations_count', 'status']; // for non-store users

    return (<>
        {error && <Alert title="Error" description={error} type="error" showIcon />}
        <ProductsList
            hideAddProduct={true}
            {...state}
            busy={busy} setBusy={setBusy}
            fetchData={fetchData}
            loading={loading}
            searchFilterConfig={props.searchFilterConfig}
            parseEditLink={(record: any) => (`${adminRoot}/store/${store._id}/product/${record._id}/view`)}
            columns={columns}
        />
    </>)
}

export default StoreProductsHome;

// export default function Wrapper(props){
//     // const { data: session, status, update } = useSession()
//     const session = useSelector((state) => state.session);

//     return (<StoreWrapper {...props} render={({ store }) => (<StoreProductsHome session={session} store={store} />)} />)
// }
