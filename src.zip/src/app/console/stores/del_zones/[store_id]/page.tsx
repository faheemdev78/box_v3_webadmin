'use client'
import React, { useState, useEffect } from 'react'
import { __error } from '@/lib/consoleHelper';
import { useMutation, useLazyQuery } from '@apollo/client/react';
import { gql } from '@apollo/client';
import { Alert, Col, Divider, message, Popconfirm, Row, Space } from 'antd';
import { Button, DevBlock, IconButton, Loader, StatusTag, Table } from '@/components';
import { ColumnsType } from 'antd/es/table';
import { adminRoot, defaultPageSize } from '@/configs';
import Link from 'next/link';
import { PageHeader } from '@/template';
import { useParams } from 'next/navigation';
import { catchApolloError, checkApolloRequestErrors } from '@/lib/utill_apollo';

import LIST_DATA from '@/graphql/geo_zone/geoZoneQuery.graphql';
import RECORD_DELETE from '@/graphql/geo_zone/deleteGeoZone.graphql';

const GET_STORE = gql`query store($_id: ID!) {
    store(_id: $_id) {
        _id title
    }
}`

function GeoZoneList({ store_id, ...props }: { store_id: any; [key: string]: any }){
    const [state, setState] = useState({
        pagination: { current: 1 },
        filter: { "store._id": store_id },
        busy: false,
    })
    const [listArray, set_listArray] = useState<any | null>(null)
    const [busy, setBusy] = useState(false)
    
    const [geoZoneQuery, { called, loading }] = useLazyQuery<any>(LIST_DATA, { fetchPolicy: 'network-only' });
    const [deleteGeoZone, del_results] = useMutation<any>(RECORD_DELETE); // { data, loading, error }
    
    useEffect(() => {
        if (called) return;
        fetchData()
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [store_id, called])

    const fetchData = async (args: { pageSize?: number; current?: number; filter?: any } = {}) => {
        let limit = args?.pageSize || defaultPageSize;
        let current = args?.current || 1;
        let skip = limit * (current - 1);

        let filter = { ...state.filter };
        if (args.filter) filter = { ...args.filter };
        if (props.filter) Object.assign(filter, { ...props.filter })

        setState({ ...state, filter, pagination: { current } })
        setBusy(true)

        const results = await geoZoneQuery({
            variables: {
                limit,
                page: skip,
                filter: JSON.stringify({}), // JSON.stringify(filter), 
                others: JSON.stringify({})
            }
        })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.geoZoneQuery }))
            .catch(catchApolloError)

        if (results && results.error) {
            message.error((results && results?.error?.message) || "No records found!")
            return false;
        }

        set_listArray(results)
    }

    const handleDelete = async ({ _id }: { _id: string }) => {
        let results = await deleteGeoZone({ variables:{ _id }})
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.deleteGeoZone }))
            .catch(catchApolloError)

        if (!results || results.error) {
            message.error((results && results?.error?.message) || "Unable to delete record")
            return false;
        }

        message.success("Record deleted")
    }

    const columns: ColumnsType<any> = [
        { title: 'Zone title', dataIndex: 'title', key: 'title', render:(___: any, rec: any) => {
            return <Link href={`${adminRoot}/stores/zone/${rec._id}`}>{rec.title}</Link>
        } },
        { title: 'Status', dataIndex: 'status', key: 'status', width: 100, align: 'center' as const },
        {
            title: 'Actions',
            dataIndex: 'actions',
            width: 120,
            key: 'actions',
            align: 'right' as const,
            render: (_text: any, rec: any) => {
                return (<Space>
                    {/* <IconButton onClick={() => set_showForm({ show: true, fields: rec })} icon="pen" /> */}
                    <Popconfirm title="Sure to delete?" onConfirm={() => handleDelete(rec)}>
                        <IconButton icon="trash-alt" />
                    </Popconfirm>
                </Space>)
            }
        },
    ];


    return (<>
        <Table
            loading={loading}
            columns={columns}
            dataSource={listArray?.edges || []}
            pagination={false}
        />
        
        {/* <DevBlock obj={listArray} /> */}
    </>)
}


function StoreZones() {
    const { store_id } = useParams<{ store_id: string }>()

    const [storeData, set_storeData] = useState<any | null>(null)
    const [fatelError, set_fatelError] = useState(null)

    const [get_store, { loading, data, called }] = useLazyQuery<any>(GET_STORE, { fetchPolicy: 'network-only' });

    useEffect(() => {
        if (called || loading || !store_id) return;
        fetchZone();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [store_id, called, loading])

    const fetchZone = async () => {
        let resutls = await get_store({ variables: { _id: store_id } })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr: any) => rr?.data?.store }))
            .catch(catchApolloError)

        if (!resutls || resutls.error) {
            set_fatelError((resutls && resutls?.error?.message) || "Store not found!")
            return;
        }

        set_storeData({ ...resutls })
    }

    if (fatelError) return <Alert title="Error" description={fatelError} type="error" showIcon />
    if (loading || (data && !storeData)) return <Loader loading={true} />
    if (!data) return <Alert title="Error" description="No data found!" type='error' showIcon />

    return (<>
        <PageHeader 
            title="Store Zones"
            sub={<div>{storeData.title}</div>}
        />

        <GeoZoneList store_id={store_id} />

    </>)
}

export default StoreZones;
