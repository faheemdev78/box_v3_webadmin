'use server'

// import { getSessionToken } from "@_/lib/auth";
// import LoginForm from "@/modules/login/LoginForm";


export default async function Login() {
    // let token = await getSessionToken()
    
    // useEffect(() => {
    //     if (!document) return;
    //     console.log(document.cookie.includes("sessionToken"));
    // }, [document]);    

    // if (token) return <p>You are already logged in</p>

    return (<div className="flex justify-center items-center h-screen">
        <p>LoginForm</p>
        {/* <LoginForm /> */}
    </div>)

}


