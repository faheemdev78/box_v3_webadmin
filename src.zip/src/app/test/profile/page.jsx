import React from 'react'


export default function ProfileHome() {
    return (<div>
        <h1>Profile Home</h1>
    </div>)
}
