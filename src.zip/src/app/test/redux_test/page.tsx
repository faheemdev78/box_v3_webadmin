'use client'

import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '@/rStore';
import { increment, decrement } from '@/rStore/slices/counterSlice'
import { setSession, clearSession } from '@/rStore/slices/sessionSlice';
import { cleanStore } from '@/rStore';
import { getSessionToken } from '@/lib/auth';

import { Space } from 'antd';


function ReduxTest() {
    const count = useSelector((state: RootState) => state.counter.value);
    const session = useSelector((state: RootState) => state.session);
    const dispatch = useDispatch();
    const token = getSessionToken();

    const login = () => dispatch(setSession({ 
        user: { 
            _id: '123',
            name: 'Test User',
            email: 'test@example.com',
            acc_type: 'tester',
            permissions: 'all',
            store: null,
        }, 
        token: 'abc123' 
    }));
    const logout = () => {
        dispatch(clearSession());
    }


    return (<div>
        <h1>Redux Test</h1>

        <h2>Counter: {count}</h2>
        <Space>
            <button onClick={() => dispatch(increment())}>Increment</button>
            <button onClick={() => dispatch(decrement())}>Decrement</button>
        </Space>

        <hr />
        <h2>Redux Session</h2>
        <Space>
            <button onClick={login}>Log-in</button>
            <button onClick={logout}>Log-out</button>
            <button onClick={() => cleanStore()}>Clear Store</button>
        </Space>
        <pre>{JSON.stringify(session, null, 2)}</pre>

        <hr />
        <h2>Cookies</h2>
        <div>{token}</div>

    </div>)
}

export default ReduxTest
