export * from './constants'
export * from './user_rights'

export const siteTitle = "Box Admin Console";
export const siteDescription = "Box Admin Console";
export const app_ver = 'web 3.1'

export const startDayOfWeek = 0; // 0 = Sunday

export const GOOGLE_API_KEY = "AIzaSyDhplL9_Tnp7Ig4lZE5TW5zme47NOeSwSw";


