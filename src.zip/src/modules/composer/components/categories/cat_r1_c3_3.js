'use client'
// import React from 'react'
// import { FormField, SubmitButton, rules, composeValidators, submitHandler } from '@/components/form';
import cssStyles from './Categories.module.scss'
import { ComponentStyling, parseStylesOutput } from '../../lib';


function Cat_r1_c3_3({ item: { data, values, styles, name } }) {
    let style = parseStylesOutput(styles)

    return (<>
        <div className={cssStyles.categories} style={style}>{values || <span style={{ color: "#999" }}>Empty Cat_r1_c3_3</span>}</div>
    </>)
}

function Cat_r1_c3_3Props({ item: { name, data, values } }) {
    return (<>
        <p>No prod props configured yet</p>
        <ComponentStyling name={name} />
    </>)
}


const Cat_r1_c3_3Component = {
    type: "cat_r1_c3_3",
    label: "R1 / C3",
    desc: "R1 / C3 (3)",
    renderer: Cat_r1_c3_3,
    propsRender: Cat_r1_c3_3Props,
    displayName: "Cat_r1_c3_3Component"
};

export default Cat_r1_c3_3Component;