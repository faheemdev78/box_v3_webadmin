'use client'
import React, { useState, useEffect } from 'react'
import { message, Row, Col, Divider, Alert, Space } from 'antd';
import { DevBlock, Loader } from '@/components';
import { catchApolloError, checkApolloRequestErrors, sleep, string_to_slug } from '@/lib/utill';
import { __error } from '@/lib/consoleHelper';
import { useMutation, useLazyQuery } from '@apollo/client/react';
import { Form as FinalForm, Field as FinalField, useForm } from 'react-final-form';
import { FormField, SubmitButton, rules, submitHandler } from '@/components/form';
import { UserTypeDD } from '@/components/dropdowns';

import GET_RECORD from '@/graphql/users/user.graphql';
import RECORD_EDIT from '@/graphql/users/editStoreStaff.graphql';


const FormComponent = ({ onSuccess, initialValues }) => {
    const [editStoreStaff, edit_details] = useMutation(RECORD_EDIT); // { data, loading, error }
    // const router = useRouter()

    const [error, setError] = useState(false);

    const onSubmit = async (values) => {
        setError(null);

        let input = {
            _id_store: initialValues.store._id,
            _id: initialValues._id,
            name: values.name,
            email: values.email,
            phone: values.phone,
            acc_type: values.acc_type,
        };

        let results = await editStoreStaff({ variables: { input } })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: false, parseReturn: (rr) => rr?.data?.editStoreStaff }))
            .catch(error => {
                console.log(__error("Error: "), error);
                return { error: { message: "Request Error!" } }
            });

        if (results.error){
            message.error(results.error.message);
            setError(results.error.message);
            return;
        }
        message.success("Saved");
        // router.push(`${adminRoot}/store/${results._id}`)
        
        if (onSuccess) onSuccess(results)
        return results;
    }


    return (<>
        <FinalForm onSubmit={onSubmit} initialValues={initialValues || undefined}
            // mutators={{
            //     ...arrayMutators,
            //     onLocationChanged: (newValueArray, state, tools) => {
            //         let val = newValueArray[0]
            //         tools.changeValue(state, 'location', () => val)
            //     },
            // }}
            render={(formargs) => {
                const { handleSubmit, submitting, form, values, invalid, errors, submitFailed } = formargs;

                return (<>
                    {error && <Alert title="Error" description={error} showIcon type='error' />}
                    <form id="StaffForm" {...submitHandler(formargs)}>

                        <Row gutter={[10, 10]}>
                            <Col span={12}><FormField type="text" name="name" label="Name" validate={rules.required} /></Col>
                            <Col span={12}><UserTypeDD name="acc_type" label="Account Type" validate={rules.required} preload /></Col>
                            <Col span={12}><FormField type="email" name="email" label="Email" validate={[rules.required, rules.isEmail]} /></Col>
                            <Col span={12}><FormField type="text" name="phone" label="Phone" validate={rules.required} /></Col>
                            {/* <Col span={6}><FormField type="select" name="acc_type" label="Account Type" options={userAccount} validate={rules.required} compact /></Col> */}

                            <Col span={24} align="right"><SubmitButton loading={submitting} label={'Save'} /></Col>
                        </Row>

                        
                        <Row>
                            <Col span={12}><DevBlock obj={values} title="values" /></Col>
                            <Col span={12}><DevBlock obj={initialValues} title="initialValues" /></Col>
                        </Row>

                    </form>
                </>)

            }}
        />

    </>)
}

export const StaffEditForm = ({ user_id, onSuccess, ...props }) => {
    const [fatelError, set_fatelError] = useState(false);
    const [error, setError] = useState(false);
    const [initialValues, set_initialValues] = useState(props.initialValues || false);
    const [get_user, { loading, data, called }] = useLazyQuery(GET_RECORD, { fetchPolicy: "no-cache" });

    useEffect(() => {
        if (called || loading || !user_id || initialValues) return;
        fetchData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user_id])

    const fetchData = async () => {
        setError(null)

        let resutls = await get_user({ variables: { _id: user_id } })
            .then(r => checkApolloRequestErrors({ results: r, allowEmpty: true, parseReturn: (rr) => rr?.data?.user }))
            .catch(catchApolloError)

        if (!resutls || resutls.error) {
            set_fatelError((resutls && resutls?.error?.message) || "Store not found!")
            return;
        }

        set_initialValues({
            ...resutls,
            // center: {
            //     ...resutls.center,
            //     coordinates: {
            //         lat: resutls.center.coordinates[0],
            //         lng: resutls.center.coordinates[1],
            //     }
            // },
        })
    }

    
    if (fatelError) return <Alert title="Error" description={fatelError} type="error" showIcon />
    if (user_id && (loading || !initialValues)) return <Loader loading={true} />
    
    return (<>
        {error && <Alert title="Error" description={error} showIcon type='error' />}
        <FormComponent {...props} initialValues={initialValues} onSuccess={onSuccess} />
    </>)
}
// StaffEditForm.propTypes = {
//     onSuccess: PropTypes.func,
//     initialValues: PropTypes.object,
//     // params: PropTypes.object,
// }
