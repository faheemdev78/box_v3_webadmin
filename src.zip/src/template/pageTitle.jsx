export function PageTitle({ children }) {
    return (<span className='page-title'>{children}</span>)
}
