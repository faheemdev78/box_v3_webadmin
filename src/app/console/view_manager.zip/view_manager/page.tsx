'use client';

import React, { useState } from 'react';
import { Card, Tabs, Button, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Page } from '@_/template';
import { useQuery } from '@apollo/client';
import { GET_ENTITY_CONFIGS } from './graphql/queries';
import { EntityConfigList } from './components/EntityConfigList';
import { EntityConfigForm } from './components/EntityConfigForm';
import { ViewTemplatesManager } from './components/ViewTemplatesManager';

export default function ViewManagerPage() {
  const [activeTab, setActiveTab] = useState('configs');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [editingConfig, setEditingConfig] = useState<any>(null);

  const { data, loading, refetch } = useQuery(GET_ENTITY_CONFIGS, {
    onError: (error) => {
      message.error(`Failed to load entity configs: ${error.message}`);
    }
  });

  const entityConfigs = data?.entityConfigs || [];

  const handleCreate = () => {
    setEditingConfig(null);
    setShowCreateForm(true);
  };

  const handleEdit = (config: any) => {
    setEditingConfig(config);
    setShowCreateForm(true);
  };

  const handleCloseForm = () => {
    setShowCreateForm(false);
    setEditingConfig(null);
  };

  const handleSuccess = () => {
    handleCloseForm();
    refetch();
    message.success(editingConfig ? 'Entity config updated successfully' : 'Entity config created successfully');
  };

  if (showCreateForm) {
    return (<Page>
        <EntityConfigForm
          config={editingConfig}
          onClose={handleCloseForm}
          onSuccess={handleSuccess}
        />
    </Page>);
  }

  return (
    <Page>
      <Card>
        <div style={{ marginBottom: 16, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ margin: 0 }}>View Filter Manager</h2>
          {activeTab === 'configs' && (
            <Button type="primary" icon={<PlusOutlined />} onClick={handleCreate}>
              Create Entity Config
            </Button>
          )}
        </div>

        <Tabs
          activeKey={activeTab}
          onChange={setActiveTab}
          items={[
            {
              key: 'configs',
              label: 'Entity Configurations',
              children: (
                <EntityConfigList
                  configs={entityConfigs}
                  loading={loading}
                  onEdit={handleEdit}
                  onRefetch={refetch}
                />
              )
            },
            {
              key: 'templates',
              label: 'View Templates',
              children: (
                <ViewTemplatesManager />
              )
            }
          ]}
        />
      </Card>
    </Page>
  );
}
